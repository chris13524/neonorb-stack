//# sourceMappingURL=account.js.map
app.controller("account",function(a){a.username=getCurrentUsername();a.currentEmail=getCurrentEmail()});