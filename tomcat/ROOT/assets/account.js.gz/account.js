//# sourceMappingURL=account.js.map
app.controller("account",["$scope",function(a){a.username=getCurrentUsername();a.currentEmail=getCurrentEmail()}]);